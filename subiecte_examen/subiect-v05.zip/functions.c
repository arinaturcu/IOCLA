#include <stdio.h>

void dark_ages()
{
	puts("We are legion!");
}
