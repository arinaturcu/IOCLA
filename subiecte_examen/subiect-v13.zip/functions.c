#include <stdio.h>

void magic_foo()
{
    printf("You got it right! \n\n");
}
