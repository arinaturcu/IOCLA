#include <stdio.h>

void omen()	
{
	puts("Power overwhelming.");
}
