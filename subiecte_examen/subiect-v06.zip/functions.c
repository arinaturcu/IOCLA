#include <stdio.h>

void pirate()
{
    printf("You are not entitled to this fortune\n");
}
